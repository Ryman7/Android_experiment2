# NoteBook
Android记事本

# 应用截图
![1](https://img-blog.csdn.net/20151207220235207)
![2](https://img-blog.csdn.net/20151207215825073)
